local _ = require("__programmable-controllers__.control.addons_utils")

--<> <?xml-stylesheet type='text/xsl' href='instructions.xsl'?>
--<> <grid>
--@@ [virtual-signal-name]
local lib = {}

_.add_hardwares(lib, require("__programmable-controllers__.controller.connector"))
_.add_hardwares(lib, require("__programmable-controllers__.controller.cpu"))
_.add_hardwares(lib, require("__programmable-controllers__.controller.extension"))
_.add_hardwares(lib, require("__programmable-controllers__.controller.memory"))
_.add_hardwares(lib, require("__programmable-controllers__.controller.power"))

_.add_instructions(lib, require("__programmable-controllers__.instructions.registers"))
_.add_instructions(lib, require("__programmable-controllers__.instructions.controls"))
_.add_instructions(lib, require("__programmable-controllers__.instructions.branchs"))
_.add_instructions(lib, require("__programmable-controllers__.instructions.maths"))
_.add_instructions(lib, require("__programmable-controllers__.instructions.bitwise"))
_.add_instructions(lib, require("__programmable-controllers__.instructions.specials"))

_.add_documentation(lib, require("__programmable-controllers__.docs.404"))
_.add_documentation(lib, require("__programmable-controllers__.docs.intro"))
_.add_documentation(lib, require("__programmable-controllers__.docs.components"))
_.add_documentation(lib, require("__programmable-controllers__.docs.power"))
_.add_documentation(lib, require("__programmable-controllers__.docs.cpu"))
_.add_documentation(lib, require("__programmable-controllers__.docs.memory"))
_.add_documentation(lib, require("__programmable-controllers__.docs.connector"))
_.add_documentation(lib, require("__programmable-controllers__.docs.extension"))
_.add_documentation(lib, require("__programmable-controllers__.docs.instructions"))
_.add_documentation(lib, require("__programmable-controllers__.docs.register"))
_.add_documentation(lib, require("__programmable-controllers__.docs.control"))
_.add_documentation(lib, require("__programmable-controllers__.docs.branching"))
_.add_documentation(lib, require("__programmable-controllers__.docs.simple_math"))
_.add_documentation(lib, require("__programmable-controllers__.docs.binary"))

--<> </grid>
return lib
