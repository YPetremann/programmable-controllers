local _ = require("__programmable-controllers__.control.addons_utils")

--<> <?xml-stylesheet type='text/xsl' href='instructions.xsl'?>
--<> <grid>
--@@ [virtual-signal-name]
local lib = {}

_.add_hardware(lib, require("__programmable-controllers__.control.controller_connector"))
_.add_hardware(lib, require("__programmable-controllers__.control.controller_cpu"))
_.add_hardware(lib, require("__programmable-controllers__.control.controller_extension"))
_.add_hardware(lib, require("__programmable-controllers__.control.controller_memory"))
_.add_hardware(lib, require("__programmable-controllers__.control.controller_power"))

_.add_instructions(lib, require("__programmable-controllers__.control.instructions_registers"))
_.add_instructions(lib, require("__programmable-controllers__.control.instructions_controls"))
_.add_instructions(lib, require("__programmable-controllers__.control.instructions_branchs"))
_.add_instructions(lib, require("__programmable-controllers__.control.instructions_maths"))
_.add_instructions(lib, require("__programmable-controllers__.control.instructions_bitwise"))
_.add_instructions(lib, require("__programmable-controllers__.control.instructions_specials"))

_.add_documentation(lib, require("__programmable-controllers__.control.docs.intro"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.components"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.power"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.cpu"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.memory"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.connector"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.extension"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.instructions"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.register"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.control"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.branching"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.simple_math"))
_.add_documentation(lib, require("__programmable-controllers__.control.docs.binary"))

--<> </grid>
return lib
