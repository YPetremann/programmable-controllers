require("control.table")

local lib = {}

function lib.add_hardwares(data, hard)
	data.classes = data.classes or {}
	table.merge(data.classes, hard)
end

function lib.add_instructions(data, soft)
	data.pci = data.pci or {}
	data.pcn = data.pcn or {}
	data.rpcn = data.rpcn or {}
	for id,v in pairs(soft) do
		local name = v[1]
		local func = v[2]
		data.pci[id] = func
		data.pcn[id] = name
		data.rpcn[name] = id
	end
end

function lib.add_documentation(data, docs)
	data.docs = data.docs or {}
	table.merge(data.docs, docs)
end

return lib