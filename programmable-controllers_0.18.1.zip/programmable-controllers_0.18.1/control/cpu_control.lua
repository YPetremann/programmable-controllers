local config = require("__programmable-controllers__.config")

local lib = {}

lib.pointer = 0
lib.brk = false

return lib