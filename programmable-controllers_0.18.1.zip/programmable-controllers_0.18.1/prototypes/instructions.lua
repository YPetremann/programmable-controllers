function DEC_HEX(IN)
	OUT = string.format("%x", IN or 0):upper()
	while #OUT<2 do OUT = "0"..OUT end
	return OUT
end
function HEX_DEC(IN)
	return tonumber(IN or 0, 16)
end
function INSTRUCTION(i,extra)
  extra = extra or false
  local int = DEC_HEX(i)
  local grp
  if extra then
    int = "Z"..int
    i = i*4
    grp = "pci"..(i<80 and "0" or "")..tostring(math.floor(i/8))
  else
    grp = "pci"..(i<80 and "0" or "")..tostring(math.floor(i/8))
  end
	if data.raw["item-subgroup"][grp] == nil then
		data:extend({{
			type = "item-subgroup",
			group = "programmable-controllers",
			name = grp,
			order = grp
		}})
	end
	data:extend({{
		type = "virtual-signal",
		name = "pci-"..int,
		icon = "__programmable-controllers__/graphics/icons/instructions/pci-"..int..".png",
		icon_size = 64,
		subgroup = grp,
		order = int
	}})
end

for i = 0,95,1 do INSTRUCTION(i) end
for i = 0,5,1 do INSTRUCTION(i,true) end