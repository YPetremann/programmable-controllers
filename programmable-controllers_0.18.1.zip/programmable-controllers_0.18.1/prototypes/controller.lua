local config = require("__programmable-controllers__.config")
local lib = {}

function lib.entity_frame(filename, x, y)
	x = x or 0
	y = y or 0
	return {
		layers = {
			{
				filename = "__programmable-controllers__/graphics/entity/hr-pc-frame-shadow.png",
				width = 128, height = 128,
				shift = {0, 0},
				scale = 0.5,
				draw_as_shadow = true
			},
			{
				filename = "__programmable-controllers__/graphics/entity/hr-pc-frame.png",
				width = 128, height = 128,
				shift = {0, 0},
				scale = 0.5
			},
			{
				filename = filename,
				width = 64,	height = 64,
				shift = {0, 0},
				scale = 0.5,
				x = x,
				y = y
			}
		}
	}
end
function lib.null_texture()
	return {
		filename = "__programmable-controllers__/graphics/null.png",
		width = 1,
		height = 1,
		frame_count = 1,
		shift = {0,0}
	}
end

function lib.add_item(name, order, icon, icon_size)
	icon_size = icon_size or 64
	data:extend({{
		type = "item",
		name = name,
		icon = icon,
		icon_size = icon_size,
		flags = {},
		subgroup = "pc-blocks",
		order = order,
		place_result = name,
		stack_size = 50
	}})
end
function lib.add_recipe(result, ingredients)
	data:extend({{
		type = "recipe",
		name = result,
		enabled = false,
		ingredients = ingredients,
		result = result,
		result_count = 1
	}})
end
function lib.add_recipe_to_tech(recipe, tech)
	tech = tech or "advanced-electronics"
	table.insert(data.raw.technology[tech].effects, {
		type = "unlock-recipe",
		recipe = recipe
	})
end
return lib