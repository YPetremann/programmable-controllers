local config = require("config")
local generic = require("prototypes.controller")
data:extend({
	{
		type = "constant-combinator",
		name = "pc-cpu",
		icon = "__programmable-controllers__/graphics/icons/pc-cpu.png",
		icon_size = 64,
		flags = {"placeable-neutral", "player-creation"},
		fast_replaceable_group = "controller",
		minable = {hardness = 0.2, mining_time = 0.5, result = "pc-cpu"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		item_slot_count = config.blocksize,
		sprites = {
			north = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-cpu.png",0,0),
			east = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-cpu.png",64,0),
			south = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-cpu.png",0,64),
			west = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-cpu.png",64,64)
		},
		activity_led_sprites = {
			north = generic.null_texture(),
			east = generic.null_texture(),
			south = generic.null_texture(),
			west = generic.null_texture()
		},

		activity_led_light = {
			intensity = 0.8,
			size = 1,
		},
		activity_led_light_offsets = {
			{0.296875, -0.40625},
			{0.25, -0.03125},
			{-0.296875, -0.078125},
			{-0.21875, -0.46875}
		},
		circuit_wire_connection_points = {
			{
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}
		},
		--circuit_wire_max_distance = 0,
		circuit_wire_max_distance = 0,
		vehicle_impact_sound = { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		energy_source = {
			type = "electric",
			usage_priority = "secondary-input"
		},
		energy_usage_per_tick = "5KW"
	}
})

generic.add_item("pc-cpu", "1-b", "__programmable-controllers__/graphics/icons/pc-cpu.png")
--generic.add_recipe("pc-cpu", {{"processing-unit",1}, {"arithmetic-combinator", 1}, {"decider-combinator", 1}, {"pc-ext",1}})
generic.add_recipe("pc-cpu", {{"advanced-circuit",1}, {"arithmetic-combinator", 1}, {"decider-combinator", 1}, {"pc-ext",1}})
generic.add_recipe_to_tech("pc-cpu", "advanced-electronics")
