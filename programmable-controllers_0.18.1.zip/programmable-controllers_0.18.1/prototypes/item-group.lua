data:extend(
{
  {
    type = "item-group",
    name = "programmable-controllers",
    icon = "__programmable-controllers__/graphics/item-group/pc-group.png",
    icon_size = 64,
    inventory_order = "d",
    order = "e"
  },
  {
    type = "item-subgroup",
    name = "pc-blocks",
    group = "programmable-controllers",
    order = "a"
  }
})
