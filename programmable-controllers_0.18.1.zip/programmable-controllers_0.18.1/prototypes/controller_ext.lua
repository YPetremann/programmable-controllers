local generic = require("prototypes.controller")
data:extend({
	{
		type = "wall",
		name = "pc-ext",
		icon = "__programmable-controllers__/graphics/icons/pc-ext.png",
		icon_size = 64,
		flags = {"placeable-neutral", "player-creation"},
		fast_replaceable_group = "controller",
		minable = {hardness = 0.2, mining_time = 0.5, result = "pc-ext"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		item_slot_count = 0,
		pictures = {
			single = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			straight_vertical = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			straight_horizontal = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			corner_right_down = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			corner_left_down = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			t_up = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			ending_right = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0),
			ending_left = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-ext.png",0,0)
		},
		activity_led_sprites = {
			north = generic.null_texture(),
			east = generic.null_texture(),
			south = generic.null_texture(),
			west = generic.null_texture()
		},
		activity_led_light = {
			intensity = 0.8,
			size = 1,
		},
		activity_led_light_offsets = {
			{0.296875, -0.40625},
			{0.25, -0.03125},
			{-0.296875, -0.078125},
			{-0.21875, -0.46875}
		},
		circuit_wire_connection_points = {
			{
				shadow = {
					red = {0.15625, -0.28125},
					green = {0.65625, -0.25}
				},
				wire = {
					red = {-0.28125, -0.5625},
					green = {0.21875, -0.5625},
				}
			}, {
				shadow = {
					red = {0.75, -0.15625},
					green = {0.75, 0.25},
				},
				wire = {
					red = {0.46875, -0.5},
					green = {0.46875, -0.09375},
				}
			}, {
				shadow = {
					red = {0.75, 0.5625},
					green = {0.21875, 0.5625}
				},
				wire = {
					red = {0.28125, 0.15625},
					green = {-0.21875, 0.15625}
				}
			}, {
				shadow = {
					red = {-0.03125, 0.28125},
					green = {-0.03125, -0.125},
				},
				wire = {
					red = {-0.46875, 0},
					green = {-0.46875, -0.40625},
				}
			}
		},
		circuit_wire_max_distance = 0
	}
})

generic.add_item("pc-ext", "1-z", "__programmable-controllers__/graphics/icons/pc-ext.png")
generic.add_recipe("pc-ext", {{"concrete",1},{"iron-plate",1},{"copper-cable", 8},{"advanced-circuit", 2}})
generic.add_recipe_to_tech("pc-ext", "advanced-electronics")
