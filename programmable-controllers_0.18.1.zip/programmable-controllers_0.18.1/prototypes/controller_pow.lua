    --~ working_sound = 
    --~ {
      --~ sound = 
      --~ {
        --~ filename = "__base__/sound/accumulator-working.ogg",
        --~ volume = 1
      --~ },
      --~ idle_sound = {
        --~ filename = "__base__/sound/accumulator-idle.ogg",
        --~ volume = 0.4
      --~ },
      --~ max_sounds_per_type = 5
    --~ },
local generic = require("prototypes.controller")
data:extend({
	{
    type = "electric-energy-interface",
		name = "pc-pow",
		icon = "__programmable-controllers__/graphics/icons/pc-pow.png",
		icon_size = 64,
		flags = {"placeable-neutral", "player-creation"},
		fast_replaceable_group = "controller",
		minable = {hardness = 0.2, mining_time = 0.5, result = "pc-pow"},
		max_health = 50,
		corpse = "small-remnants",
		collision_box = {{-0.3, -0.3}, {0.3, 0.3}},
		selection_box = {{-0.5, -0.5}, {0.5, 0.5}},
		item_slot_count = 32,
		picture = generic.entity_frame("__programmable-controllers__/graphics/entity/hr-pc-pow.png",0,0),
		activity_led_sprites = {
			north = generic.null_texture(),
			east = generic.null_texture(),
			south = generic.null_texture(),
			west = generic.null_texture()
		},
		activity_led_light = {
			intensity = 0.8,
			size = 1,
		},
		activity_led_light_offsets = {
			{0.296875, -0.40625},
			{0.25, -0.03125},
			{-0.296875, -0.078125},
			{-0.21875, -0.46875}
		},
		circuit_wire_connection_points = {
			{
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}, {
				shadow = {
					red = {0.859375, -0.296875},
					green = {0.859375, -0.296875},
				},
				wire = {
					red = {0.40625, -0.59375},
					green = {0.40625, -0.59375},
				}
			}
		},
		circuit_wire_max_distance = 0,
		vehicle_impact_sound = { filename = "__base__/sound/car-metal-impact.ogg", volume = 0.65 },
		energy_source = {
			type = "electric",
			buffer_capacity = "1MJ",
			usage_priority = "secondary-input",
			input_flow_limit = "150kW",
			output_flow_limit = "0kW"
		},
    energy_production = "0kW",
    energy_usage = "0kW",
		energy_usage_per_tick = "10KW"
	}
})

generic.add_item("pc-pow", "1-a", "__programmable-controllers__/graphics/icons/pc-pow.png")
generic.add_recipe("pc-pow", {{"battery",2}, {"copper-cable",8}, {"pc-ext",1}})
generic.add_recipe_to_tech("pc-pow", "advanced-electronics")
