return {
	menu = {
		components={
			extension=1
		}
	},
	pages = {
		["extension"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_extension_text_1"}}
		end
	}
}