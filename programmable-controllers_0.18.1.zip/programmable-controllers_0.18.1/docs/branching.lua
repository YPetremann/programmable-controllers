return {
	menu = {
		instructions={
			branching=1
		}
	},
	pages = {
		["branching"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_branching_text_1"}}
		end
	}
}