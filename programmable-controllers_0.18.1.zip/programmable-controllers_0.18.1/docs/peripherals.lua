return {
	menu = {
		components = {}
	},
	pages = {
		["components"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_components_text_1"}}
		end
	}
}