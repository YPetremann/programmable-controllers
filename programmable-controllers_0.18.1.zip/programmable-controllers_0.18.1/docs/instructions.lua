return {
	menu = {
		instructions={}
	},
	pages = {
		["instructions"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_instructions_text_1"}}
		end
	}
}