return {
	menu = {
		instructions={
			binary=1
		}
	},
	pages = {
		["binary"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_binary_text_1"}}
		end
	}
}