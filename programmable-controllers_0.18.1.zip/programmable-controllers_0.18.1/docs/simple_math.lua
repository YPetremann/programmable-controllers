return {
	menu = {
		instructions={
			simple_math=1
		}
	},
	pages = {
		["simple_math"] = function(data)
			data.element.add{type = "label", caption = {"pc-docs.page_simple_math_text_1"}}
		end
	}
}